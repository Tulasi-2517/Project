package librarymanagement;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = Library.getInstance();

        Book book1 = BookFactory.createBook("Fiction", "1984", "George Orwell");
        Book book2 = BookFactory.createBook("Non-Fiction", "Sapiens", "Yuval Noah Harari");

        Member member1 = new Member("Alice");
        Member member2 = new Member("Bob");

        LibraryMember observer1 = new LibraryMember("Alice");
        LibraryMember observer2 = new LibraryMember("Bob");

        library.registerObserver(observer1);
        library.registerObserver(observer2);

        Librarian librarian = new Librarian();

        librarian.addBook(book1, library);
        librarian.addBook(book2, library);

        librarian.issueBook(book1, member1, library);
        librarian.returnBook(book1, member1, library);

        librarian.issueBook(book2, member2, library);
        librarian.returnBook(book2, member2, library);
    }
}
