package librarymanagement;

class Transaction {
    Member member;
    Book book;
    String transactionType;

    public Transaction(Member member, Book book, String transactionType) {
        this.member = member;
        this.book = book;
        this.transactionType = transactionType;
    }
}
