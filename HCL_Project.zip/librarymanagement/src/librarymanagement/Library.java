package librarymanagement;

import java.util.ArrayList;
import java.util.List;

class Library {
    private static Library instance;
    private List<Book> books;
    private List<Transaction> transactions;
    private List<Observer> observers;

    private Library() {
        books = new ArrayList<>();
        transactions = new ArrayList<>();
        observers = new ArrayList<>();
    }

    public static Library getInstance() {
        if (instance == null) {
            instance = new Library();
        }
        return instance;
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void removeBook(Book book) {
        books.remove(book);
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }

    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    public void notifyObservers(String message, String memberName) {
        for (Observer observer : observers) {
            if (observer instanceof LibraryMember && ((LibraryMember) observer).getName().equals(memberName)) {
                observer.update(message);
            }
        }
    }
}
